using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Performance.Profile-Analyzer.EditorTests")]
